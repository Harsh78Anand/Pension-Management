interface Pensioner {
    
    name: string;
    dateOfBirth:Date;
    pan:string;
    aadhaarNumber:string;
    familyPension:boolean;
    
  }
export { Pensioner };
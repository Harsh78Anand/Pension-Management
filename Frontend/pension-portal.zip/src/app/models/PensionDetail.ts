interface PensionDetail {
    
    name: string;
    dateOfBirth:Date;
    pan:string;
    pensionAmount: number;
    familyPension:boolean;
    
  }
export { PensionDetail };
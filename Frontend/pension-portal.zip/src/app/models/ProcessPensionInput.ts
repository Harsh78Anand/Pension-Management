interface ProcessPensionInput {
    
    aadhaarNumber:string;
    pensionAmount: number;
    bankServiceCharge: number;
    
  }
export { ProcessPensionInput };
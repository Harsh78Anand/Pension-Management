import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcessPensionInputComponent } from './process-pension-input.component';

describe('ProcessPensionInputComponent', () => {
  let component: ProcessPensionInputComponent;
  let fixture: ComponentFixture<ProcessPensionInputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProcessPensionInputComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcessPensionInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
